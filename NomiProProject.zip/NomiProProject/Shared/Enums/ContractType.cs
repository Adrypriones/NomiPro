﻿
namespace NomiProProject.Shared.Enums
{
    public enum ContractType
    {
        ContratoIndefinido = 1,
        PrestacionServicios = 2
    }
}