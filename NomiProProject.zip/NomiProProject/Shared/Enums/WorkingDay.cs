﻿namespace NomiProProject.Shared.Enums
{
    public enum WorkingDay
    {
        Day = 1,
        Night = 2
    }
}