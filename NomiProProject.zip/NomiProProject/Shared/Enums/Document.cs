﻿namespace NomiProProject.Shared.Enums
{
    public enum Document
    {
        CC = 1,
        CE = 2
    }
}