﻿
namespace NomiProProject.Shared.Enums
{
    public enum Gender
    {
        Masculino = 1,
        Femenino = 2
    }
}